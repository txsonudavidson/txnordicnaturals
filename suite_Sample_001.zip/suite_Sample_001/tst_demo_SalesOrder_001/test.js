source(findFile("scripts", "Libraries/Application.js"))
source(findFile("scripts", "Libraries/Global.js"))
source(findFile("scripts", "Libraries/Constants.js"))
source(findFile("scripts", "Libraries/Perf.js"))


function main() 
{
    var objApp = new Application();
    var Global = new GlobalVariables();
    
    testSettings.logScreenshotOnPass = true;
    testSettings.logScreenshotOnError = true;
    testSettings.logScreenshotOnPass = true;
    
    objApp.start(Global.xTupleName);
    test.pass("Start " + Global.xTupleName + " application.","Application has been successfully");
    
    var bStatus = false;
    
    bStatus = objApp.login();
    if(bStatus) test.pass("Login to the application","Logged in to the application successfully");
    else test.fail("Login to application","Unable to login to application");
    
    bStatus = objApp.navigateToSalesCustomersScreen();
    if(bStatus) test.pass("Navigate to Sales-->Customer","Navigation successful");
    else test.fail("Navigate to Sales-->Customer","Unable to navigate");
    
    objApp.disableDefaultQueryOnStart(":customers_QMenu",":customers._queryBtn_QToolButton");
    test.pass("Disable 'Query on Start'","Default 'Query on Start' has been disabled");
    
    //Test data of the customer
    var dsCustomerDetails = testData.dataset("CustomerDetails.tsv");
    
    objApp.searchAndSelectCustomer(testData.field(dsCustomerDetails[0],"Filter Criteria"),testData.field(dsCustomerDetails[0],"Value"));
    test.pass("Search for the customer " + testData.field(dsCustomerDetails[0],"Value"),"Customer details are being fetched successfully");
    
    objApp.openNewSalesOrderWindow();
    test.pass("Open new sales order window","New sales order has been successfully launched");
    
    var dsOrderDetails = testData.dataset("OrderDetails.tsv");
    
    objApp.addNewLineItem(testData.field(dsOrderDetails[0],"Product Name"), testData.field(dsOrderDetails[0],"Product Quantity"), true, true);
    test.pass("Add new line item","New sales order has been added at the line level successfully");
    
    test.compare(waitForObjectExists(":lblLineItemProductName").text, "RUS-01500");
    test.compare(waitForObjectExists(":lblLineItemProductQty").text, "2.000");
    test.compare(waitForObjectExists(":_soitem.59.95000_QModelIndex").text, "59.95000");
    test.compare(waitForObjectExists(":_soitem.119.90_QModelIndex").text, "119.90");
    test.compare(waitForObjectExists(":_soitem.0.000_QModelIndex").text, "0.000");
}