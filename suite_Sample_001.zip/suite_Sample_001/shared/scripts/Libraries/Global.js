function GlobalVariables()
{
    //Applcation Process Name
    this.xTupleName = "xtuple";
    
    //Login Details
    this.LoginUserName = "";
    this.LoginPassword = "";
    this.ServerName = "";
    this.PortNo = "";
    this.DataBaseName = "";
    
    this.gErrMsg = "";
}