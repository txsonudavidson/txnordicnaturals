source(findFile("scripts", "Libraries/Global.js"))
source(findFile("scripts", "Libraries/Constants.js"))
source(findFile("scripts", "Libraries/Perf.js"))

function Application()
{
    
    var objGlobal = new GlobalVariables();
    var objConstants = new Constants();
    var objPerf = new Perf();
    
    this.start = function start(sAutName)
    {
        objPerf.startPerf("Transaction Name: Launch xTuple Application");
        
        startApplication(sAutName);
        
        objPerf.stopPerf("Transaction Name: Launch xTuple Application");
    }
    
    function updateLoginInfo()
    {
        var dataset = testData.dataset("LoginDetails.tsv");
        
        for (var record in dataset) 
        {
            objGlobal.LoginUserName = testData.field(dataset[record], "LoginUserName");
            objGlobal.LoginPassword = testData.field(dataset[record], "LoginPassword");
            objGlobal.ServerName = testData.field(dataset[record], "ServerName");
            objGlobal.PortNo = testData.field(dataset[record], "PortNo");
            objGlobal.DataBaseName = testData.field(dataset[record], "DataBaseName");
        }
    }

    this.login = function loginToApplication()
    {
        updateLoginInfo();
        
        objPerf.startPerf("Transaction Name: Login to Application");
        
        waitForObject(":frmLogin", objConstants.WaitForObjectTimeOut);
        
        type(waitForObject(":txtLoginUserName"), objGlobal.LoginUserName);
        type(waitForObject(":txtLoginPassword"), objGlobal.LoginPassword);
        mouseClick(waitForObject(":txtServerName"));
        type(waitForObject(":txtServerName"),"<Ctrl+A>");
        type(waitForObject(":txtServerName"), objGlobal.ServerName);
        mouseClick(waitForObject(":txtPortNumber"));
        doubleClick(waitForObject(":txtPortNumber"));
        type(waitForObject(":txtPortNumber"), objGlobal.PortNo);
        mouseClick(waitForObject(":txtDatabase"));
        doubleClick(waitForObject(":txtDatabase"));
        type(waitForObject(":cmbDatabase"), objGlobal.DataBaseName);
        clickButton(waitForObject(":btnLogin"));
   
        waitForObject(":SplashScreen");
        waitForObject(":frmHome");
        
        objPerf.stopPerf("Transaction Name: Login to Application");
        
        return true;
    }
    
    this.navigateToMenu = function navigateToMenu(sMenuPath)
    {   
        var arrMenuPath = sMenuPath.split("|");
        
        activateItem(waitForObjectItem(":MainMenuBar", arrMenuPath[0]));
        
        for (var iLoopCounter = 1; iLoopCounter < arrMenuPath.length - 1; iLoopCounter++) 
        {
            activateItem(waitForObjectItem(":MenuItem", arrMenuPath[iLoopCounter]));
        }
        
        if(sMenuPath.includes("Customer"))
        {
            activateItem(waitForObjectItem(":menu.sales.customer_QMenu",arrMenuPath[arrMenuPath.length - 1]))
        }
    }
    
    this.navigateToSalesCustomersScreen = function navigateToSalesCustomersScreen()
    {
        objPerf.startPerf("Transaction Name: Navigate to Sales|Customer|List");
        
        activateItem(waitForObjectItem(":MainMenuBar", "Sales"));
        activateItem(waitForObjectItem(":MenuItem", "Customer"));
        activateItem(waitForObjectItem(":menu.sales.customer_QMenu","List..."));
        
        waitForObject(":frmCustomers");
        
        objPerf.stopPerf("Transaction Name: Navigate to Sales|Customer|List");
        
        return true;
    }
    
    this.disableDefaultQueryOnStart = function disableQueryOnStart(menuControl, controlToUnCheck)
    {
        objPerf.startPerf("Transaction Name: Disable Query on Start");
        
        sendEvent("QMouseEvent", waitForObject(controlToUnCheck), QEvent.MouseButtonPress, 50, 12, Qt.LeftButton, 1, 0);
        
        var obj = waitForObject(controlToUnCheck);
        var Prp = object.properties(obj);
        
        var bChecked = Prp["checked"];
        if(bChecked) return;
        else
        {
            sendEvent("QMouseEvent", waitForObject(controlToUnCheck), QEvent.MouseButtonPress, 50, 12, Qt.LeftButton, 1, 0);
            activateItem(waitForObjectItem(menuControl, "Query on start"));
        }
        
        objPerf.stopPerf("Transaction Name: Disable Query on Start");
    }
    
    this.searchAndSelectCustomer = function searchAndSelectCustomer(sFilterCriteria, sFilterValue)
    {
        objPerf.startPerf("Transaction Name: Search for Customer");
        
        clickButton(waitForObject(":_filterGroup._addFilterRow_QToolButton"));
        
        mouseClick(waitForObjectItem(":_filterGroup.xcomboBox1_XComboBox", sFilterCriteria));
        
        type(waitForObject(":_filterGroup.widget1_QLineEdit"), sFilterValue);
        
        clickButton(waitForObject(":customers._queryBtn_QToolButton"));
        
        waitForObjectItem(":_list_XTreeWidget", sFilterValue);
        
        objPerf.stopPerf("Transaction Name: Search for Customer");
        
        doubleClickItem(":_list_XTreeWidget", "" + sFilterValue, 10, 10, 0, Qt.LeftButton);
        
        objPerf.startPerf("Transaction Name: Wait for Customer Details");
        
        waitForObjectExists(":customer._tab_QTabWidget");
        
        objPerf.stopPerf("Transaction Name: Wait for Customer Details");

        //waitForObjectItem(":_list_XTreeWidget", "500000917");
        //doubleClickItem(":_list_XTreeWidget", "500000917", 27, 6, 0, Qt.LeftButton);
        //clickTab(waitForObject(":customer._tab_QTabWidget"), "Sales");
        //clickButton(waitForObject(":_salesTab._ordersButton_QRadioButton"));
        
        //doubleClickItem(":_list_XTreeWidget", sFilterValue);
    }
    
    this.openNewSalesOrderWindow = function openNewSalesOrderWindow()
    {
        clickTab(waitForObject(":customer._tab_QTabWidget"), "Sales");
        
        objPerf.startPerf("Transaction Name: Open New Sales Order Window");
        
        clickButton(waitForObject(":_salesTab._ordersButton_QRadioButton"));

        clickButton(waitForObject(":_salesStack._newBtn_QToolButton"));
        test.compare(waitForObjectExists(":salesOrder new_salesOrder").windowTitle, "Sales Order");
        mouseClick(waitForObject(":salesOrder new_salesOrder"), 356, 9, 0, Qt.LeftButton);
        waitForObject(":salesOrder new._salesOrderInformation_QTabWidget");
        
        objPerf.stopPerf("Transaction Name: Open New Sales Order Window");
    }
    
    this.addNewLineItem = function addNewLineItem(ProductName, ProductQuantity, bReserve, bRefreshOrder)
    {
        objPerf.startPerf("Transaction Name: Add New Line Item");
        
        clickTab(waitForObject(":salesOrder new._salesOrderInformation_QTabWidget"), "Line Items");
        
        clickButton(waitForObject(":_lineItemsPage._new_QPushButton"));
        sendEvent("QMouseEvent", waitForObject(":_itemGroup_QLabel"), QEvent.MouseButtonPress, 13, 10, Qt.LeftButton, 1, 0);
        
        objPerf.startPerf("Transaction Name: Search Product");
        
        activateItem(waitForObjectItem(":_QMenu", "List..."));
        type(waitForObject(":_search_QLineEdit"), ProductName);
        waitForObjectItem(":_listTab_XTreeWidget", ProductName);
        clickItem(":_listTab_XTreeWidget", ProductName,10, 10, 0, Qt.LeftButton);
        clickButton(waitForObject(":_itemGroup.OK_QPushButton"));
        
        objPerf.stopPerf("Transaction Name: Search Product");
        
        type(waitForObject(":_qtyOrdered_XLineEdit"), ProductQuantity);
        
        var chkReserve = waitForObject(":salesOrderItem._reserveOnSave_XCheckBox");
        var Prp = object.properties(chkReserve);
        var bChecked = Prp["checked"];
        
        if(bReserve)
        {
            if(bChecked == false)
            {
                clickButton(waitForObject(":salesOrderItem._reserveOnSave_XCheckBox"));
            }
        }
        
        if(!bReserve)
        {
            if(bChecked == true)
            {
                clickButton(waitForObject(":salesOrderItem._reserveOnSave_XCheckBox")); 
            }
        }
        
        var chkRefresh = waitForObject(":salesOrderItem._orderRefresh_XCheckBox");
        var RefreshPrp = object.properties(chkRefresh);
        bChecked = RefreshPrp["checked"];
        
        if(bRefreshOrder)
        {
            if(bChecked == false)
            {
                clickButton(waitForObject(":salesOrderItem._orderRefresh_XCheckBox"));
            }
        }
        
        if(!bRefreshOrder)
        {
            if(bChecked == true)
            {
                clickButton(waitForObject(":salesOrderItem._orderRefresh_XCheckBox")); 
            }
        }
        
        clickButton(waitForObject(":salesOrderItem._save_QPushButton"));
        clickButton(waitForObject(":salesOrderItem._close_QPushButton"));
        
        clickButton(waitForObject(":salesOrder new._save_QPushButton"));
        
        objPerf.stopPerf("Transaction Name: Add New Line Item");
    }
}