function Constants()
{
    this.WaitForObjectTimeOut = 60;       
}